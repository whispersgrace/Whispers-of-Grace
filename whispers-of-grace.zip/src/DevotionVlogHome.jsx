
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail } from "lucide-react";

export default function DevotionVlogHome() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-100 via-white to-emerald-100 p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold text-rose-700">Whispers of Grace</h1>
        <p className="mt-2 text-gray-700 text-lg italic">
          A sacred space for daily devotionals, prayers, and reflections
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold text-emerald-700 mb-2">Today's Devotional</h2>
            <div className="aspect-video bg-gray-200 rounded-lg mb-2" />
            <p className="text-gray-600">
              "Delight yourself in the Lord, and He will give you the desires of your heart." - Psalm 37:4
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold text-rose-700 mb-2">Submit a Prayer Request</h2>
            <form className="space-y-3">
              <Input placeholder="Your Name" />
              <Input placeholder="Your Email" type="email" />
              <Textarea placeholder="Your Prayer Request..." rows={4} />
              <Button className="bg-rose-600 hover:bg-rose-700">Send Prayer</Button>
            </form>
          </CardContent>
        </Card>
      </section>

      <section className="bg-white p-6 rounded-xl shadow-sm">
        <h2 className="text-xl font-bold text-center mb-4 text-emerald-700">
          Subscribe for Daily Inspiration 💌
        </h2>
        <form className="flex flex-col md:flex-row justify-center items-center gap-4">
          <Input placeholder="Enter your email..." className="w-full md:w-1/2" />
          <Button className="bg-emerald-600 hover:bg-emerald-700 flex items-center gap-1">
            <Mail className="w-4 h-4" /> Subscribe
          </Button>
        </form>
      </section>

      <footer className="mt-10 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Whispers of Grace. All rights reserved.
      </footer>
    </div>
  );
}
